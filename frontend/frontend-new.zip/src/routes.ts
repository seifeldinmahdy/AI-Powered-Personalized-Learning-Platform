import { createBrowserRouter } from "react-router";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import LiveSession from "./pages/LiveSession";
import AdminDashboard from "./pages/AdminDashboard";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    children: [
      { index: true, Component: Dashboard },
      { path: "login", Component: Login },
      { path: "dashboard", Component: Dashboard },
      { path: "profile", Component: Profile },
      { path: "course/:courseId/lesson/:lessonId", Component: LiveSession },
      { path: "admin", Component: AdminDashboard },
      { path: "*", Component: NotFound },
    ],
  },
]);